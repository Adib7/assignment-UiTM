import java.net.*;
import java.io.*;


class Server
{
	public static void main(String argv[]) throws Exception
	{
	String clientMatric;
	ServerSocket welcomeSocket = new ServerSocket(8081);
	System.out.println("Waiting Matrix from Server A...");

	while(true)
	{
	Socket connectionSocket = welcomeSocket.accept();
	BufferedReader inputClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
	DataOutputStream outputClient = new DataOutputStream(connectionSocket.getOutputStream());
	clientMatric = inputClient.readLine();
	System.out.println("Received: " + clientMatric);
	}
	}
}
