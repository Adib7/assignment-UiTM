import java.net.*;
import java.io.*;


class Client
{
public static void main(String argv[]) throws Exception
{
String Matric;
String Sentence;
BufferedReader inServer = new BufferedReader( new InputStreamReader(System.in));
Socket clientSocket = new Socket("localhost", 6000);
DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
Matric = inServer.readLine();
outToServer.writeBytes(Matric + '\n');
Sentence = inFromServer.readLine();
System.out.println("FROM SERVER: " + Sentence);
clientSocket.close();
}
}
